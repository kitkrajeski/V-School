const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const houseSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    region: {
        type: String,
        required: true
    },
    words: {
        type: String,
        required: true
    },
    crest: {
        type: String,
        required: false
    }
})

const House = mongoose.model('House', houseSchema);

module.exports = House;