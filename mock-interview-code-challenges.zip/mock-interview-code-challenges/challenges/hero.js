function hero(bullets, dragons) {
  //Get Coding!
}
